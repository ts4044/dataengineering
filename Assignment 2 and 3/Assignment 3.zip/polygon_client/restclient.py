class RestClient:
    @staticmethod
    def fetch_key():
        key = "beBybSi8daPgsTp5yx5cHtHpYcrjp5Jq"
        return key
