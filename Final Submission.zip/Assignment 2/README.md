
# Polygon Rest Client

### Assignment 1
This library is a helper to fetch the key for Polygon Client. The library can be imported as follows:
```
from polygon_client import RestClient
```

To fetch the key, you can use the fetch_key() method.
```
key = RestClient.fetch_key()
client = RESTClient(key)
```

### Assignment 2
Run _code.py_. Creates a CSV file of the following format :
```
"Reading Number", "Currency", "Max", "Min", "Mean", "Vol", "FD"
```